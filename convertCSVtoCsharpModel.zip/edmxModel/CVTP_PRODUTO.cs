namespace Aperam.PCP.PNV.Negocio.Modelos
{
    using System;
    using System.Collections.Generic;

    public partial class CVTP_PRODUTO
    {
        public string NUN_SEQ_CVTP { get; set; }
        public string COD_SEG_CVTP { get; set; }
        public string COD_CLIENTE { get; set; }
        public string COD_LINHA_PRODT { get; set; }
        public string COD_REVIS_CVTP { get; set; }
        public string COD_AREA_APLIC { get; set; }
        public string COD_SITUA_CVTP { get; set; }
        public string DESC_COMPLEX_CVTP { get; set; }
        public string COD_REG_USUAR { get; set; }
        public string COD_REG_EMPRG { get; set; }
        public string COD_MERC_CVTP { get; set; }
        public string DESC_OUTRO_SEG { get; set; }
        public string DESC_MOTIV_CONSULTA { get; set; }
        public string COD_ENVIO_CUSTO { get; set; }
        public string COD_SETOR_AUTOMOT { get; set; }
        public string ACO_INTERN_CVTP { get; set; }
        public string COD_IDENT_FMACO { get; set; }
        public string COD_IDENT_ACOEX { get; set; }
        public string COD_ACAB_REVEST { get; set; }
        public string DESC_GRUPO_CVTP { get; set; }
        public string DESC_APLIC_CVTP { get; set; }
        public string DESC_QTD_FORNEC { get; set; }
        public string NORMA_REFER_CVTP { get; set; }
        public string COD_NORM_CLIENTE { get; set; }
        public string DESC_NORMA_CLIENTE { get; set; }
        public string DESC_COMP_QUIMICA { get; set; }
        public string COD_DIMENS_PROD { get; set; }
        public string DESC_TOLER_PROD { get; set; }
        public string DESC_PADRONIZ_ESP { get; set; }
        public string QTD_CONJ_DIMENS { get; set; }
        public string PES_LIQUI_PROD { get; set; }
        public string POS_BOB_TIRA { get; set; }
        public string DIAM_INTERN_BOB { get; set; }
        public string VLR_DIAM_ESPEC { get; set; }
        public string COD_ENSAIO_LABOR { get; set; }
        public string VLR_DUREZA_MIN { get; set; }
        public string VLR_DUREZA_MAX { get; set; }
        public string VLR_UNID_DUREZA { get; set; }
        public string LIMIT_ESCUM_MIN { get; set; }
        public string LIMIT_ESCUM_MAX { get; set; }
        public string LIMIT_ESCUM_UNID { get; set; }
        public string LIMIT_ESCDOIS_MIN { get; set; }
        public string LIMIT_ESCDOIS_MAX { get; set; }
        public string LIMIT_ESCDOIS_UNID { get; set; }
        public string LIMIT_RES_MIN { get; set; }
        public string LIMIT_RES_MAX { get; set; }
        public string LIMIT_RES_UNID { get; set; }
        public string VRL_ALONG_MIN { get; set; }
        public string VRL_ALONG_MAX { get; set; }
        public string VRL_ALONG_UNID { get; set; }
        public string TAM_GRAO_MIN { get; set; }
        public string TAM_GRAO_MAX { get; set; }
        public string TAM_GRAO_UNID { get; set; }
        public string VLR_OXALICO_MIN { get; set; }
        public string VLR_OXALICO_MAX { get; set; }
        public string VLR_OXALICO_UNID { get; set; }
        public string VLR_IMPACTO_MIN { get; set; }
        public string VLR_IMPACTO_MAX { get; set; }
        public string VLR_IMPACTO_UNID { get; set; }
        public string VLR_OUTROS { get; set; }
        public string VLR_OUTRO_MIN { get; set; }
        public string VLR_OUTRO_MAX { get; set; }
        public string VLR_OUTRO_UNID { get; set; }
        public string COD_TIPO_PERDA { get; set; }
        public string VLR_INDUC { get; set; }
        public string VRL_FREQUENCIA { get; set; }
        public string VALOR_WKG { get; set; }
        public string DESC_INFORMAC_FORN { get; set; }
        public DateTime DTH_CADAST_CVTP { get; set; }
        public string DESC_RECUSA_CVTP { get; set; }
        public DateTime DTH_RECUSA_CVTP { get; set; }
        public DateTime DTH_RECEB_CVTP { get; set; }
        public DateTime DTH_CADAST_RVTP { get; set; }
        public DateTime DTH_ANALIS_RVTP { get; set; }
        public string COD_ARQUI_ANEXO { get; set; }

        public virtual CVTP_SEGUIMENTO CVTP_SEGUIMENTO { get; set; }
    }
}