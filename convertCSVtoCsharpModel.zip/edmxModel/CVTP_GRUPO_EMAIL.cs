namespace Aperam.PCP.PNV.Negocio.Modelos
{
    using System;
    using System.Collections.Generic;

    public partial class CVTP_GRUPO_EMAIL
    {
        public string COD_GRUPO_AREA { get; set; }
        public int NUN_SEQ_CVTP { get; set; }
        public string DESC_GRUPO_AREA { get; set; }
        public string AREA_GRUPO_DIREC { get; set; }
        public string SUBAREA_GRUPO_DIREC { get; set; }
        public DateTime DTH_CAD_REG { get; set; }
        public string COD_REG_USUAR { get; set; }
        public string COD_REG_EMPRG { get; set; }

        public virtual CVTP_PRODUTO CVTP_PRODUTO { get; set; }
    }
}