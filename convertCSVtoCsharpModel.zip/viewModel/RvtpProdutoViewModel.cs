using System;
using System.ComponentModel.DataAnnotations;

namespace Aperam.PCP.PNV.UI.ViewModels
{
    public class RVTP_PRODUTOViewModel
    {
        [Display(Name = "N�mero Sequ�ncia RVTP")]
        public int NUN_SEQ_RVTP { get; set; }

        [Display(Name = "N�mero Sequ�ncia CVTP")]
        public int? NUN_SEQ_CVTP { get; set; }

        [Display(Name = "Cliente")]
        public int? COD_CLIENTE { get; set; }

        [Display(Name = "Linha Produto")]
        public string COD_LINHA_PRODT { get; set; }

        [Display(Name = "Revis�o CVTP")]
        [RegularExpression("^(NV, RB, PR, RC,CC, CA)$", ErrorMessage = "O valor não é permitido.")]
        public int? COD_REVIS_CVTP { get; set; }

        [Display(Name = "�rea Aplicação")]
        public string COD_AREA_APLIC { get; set; }

        [Display(Name = "Situação CVTP")]
        public string COD_SITUA_CVTP { get; set; }

        [Display(Name = "Descrição Complexo CVTP")]
        public string DESC_COMPLEX_CVTP { get; set; }

        [Display(Name = "Registro Usu�rio")]
        public int? COD_REG_USUAR { get; set; }

        [Display(Name = "Registro Empregado")]
        public int? COD_REG_EMPRG { get; set; }

        [Display(Name = "Mercado CVTP")]
        public string COD_MERC_CVTP { get; set; }

        [Display(Name = "Segmento CVTP")]
        public string COD_SEG_CVTP { get; set; }

        [Display(Name = "Outro Segmento")]
        [RegularExpression("^(MI, ME)$", ErrorMessage = "O valor não é permitido.")]
        public string DESC_OUTRO_SEG { get; set; }

        [Display(Name = "Motivo Consulta")]
        public string DESC_MOTIV_CONSULTA { get; set; }

        [Display(Name = "Envio Custo")]
        public string COD_ENVIO_CUSTO { get; set; }

        [Display(Name = "Setor Automotivo")]
        public string COD_SETOR_AUTOMOT { get; set; }

        [Display(Name = "A�o Interno CVTP")]
        public string ACO_INTERN_CVTP { get; set; }

        [Display(Name = "Identificação FMA�O")]
        public string COD_IDENT_FMACO { get; set; }

        [Display(Name = "Identificação A�OEX")]
        public string COD_IDENT_ACOEX { get; set; }

        [Display(Name = "Acabamento Revestimento")]
        public string COD_ACAB_REVEST { get; set; }

        [Display(Name = "Grupo CVTP")]
        public string DESC_GRUPO_CVTP { get; set; }

        [Display(Name = "Aplicação CVTP")]
        public string DESC_APLIC_CVTP { get; set; }

        [Display(Name = "Quantidade Fornecedor")]
        public int? DESC_QTD_FORNEC { get; set; }

        [Display(Name = "Norma Refer�ncia CVTP")]
        public string NORMA_REFER_CVTP { get; set; }

        [Display(Name = "Norma Cliente")]
        public string COD_NORM_CLIENTE { get; set; }

        [Display(Name = "Norma Cliente")]
        public string DESC_NORMA_CLIENTE { get; set; }

        [Display(Name = "Composição Qu�mica")]
        [RegularExpression("^(s,n)$", ErrorMessage = "O valor não é permitido.")]
        public string DESC_COMP_QUIMICA { get; set; }

        [Display(Name = "Dimens�o Produto")]
        public string COD_DIMENS_PROD { get; set; }

        [Display(Name = "Toler�ncia Produto")]
        [RegularExpression("^(P, E)$", ErrorMessage = "O valor não é permitido.")]
        public string DESC_TOLER_PROD { get; set; }

        [Display(Name = "Padronização Espessura")]
        [RegularExpression("^(P, E)$", ErrorMessage = "O valor não é permitido.")]
        public string DESC_PADRONIZ_ESP { get; set; }

        [Display(Name = "Conjunto Dimens�es")]
        [RegularExpression("^(A, P, E)$", ErrorMessage = "O valor não é permitido.")]
        public int? QTD_CONJ_DIMENS { get; set; }

        [Display(Name = "Peso L�quido Produto")]
        [RegularExpression("^(C, N, P)$", ErrorMessage = "O valor não é permitido.")]
        public int? PES_LIQUI_PROD { get; set; }

        [Display(Name = "Posição Bobina Tira")]
        public string POS_BOB_TIRA { get; set; }

        [Display(Name = "Di�metro Interno Bobina")]
        [RegularExpression("^(P, E)$", ErrorMessage = "O valor não é permitido.")]
        public string DIAM_INTERN_BOB { get; set; }

        [Display(Name = "Di�metro Espec�fico")]
        [RegularExpression("^(H, V)$", ErrorMessage = "O valor não é permitido.")]
        public int? VLR_DIAM_ESPEC { get; set; }

        [Display(Name = "Ensaio Laborat�rio")]
        [RegularExpression("^(P,E)$", ErrorMessage = "O valor não é permitido.")]
        public string COD_ENSAIO_LABOR { get; set; }

        [Display(Name = "Dureza M�nima")]
        [RegularExpression("^(P,E)$", ErrorMessage = "O valor não é permitido.")]
        public int? VLR_DUREZA_MIN { get; set; }

        [Display(Name = "Dureza M�xima")]
        public int? VLR_DUREZA_MAX { get; set; }

        [Display(Name = "Unidade Dureza")]
        public string VLR_UNID_DUREZA { get; set; }

        [Display(Name = "Escumação M�nima")]
        public int? LIMIT_ESCUM_MIN { get; set; }

        [Display(Name = "Escumação M�xima")]
        public int? LIMIT_ESCUM_MAX { get; set; }

        [Display(Name = "Escumação Unidade")]
        public string LIMIT_ESCUM_UNID { get; set; }

        [Display(Name = "Escurecimento M�nima")]
        public int? LIMIT_ESCDOIS_MIN { get; set; }

        [Display(Name = "Escurecimento M�xima")]
        public int? LIMIT_ESCDOIS_MAX { get; set; }

        [Display(Name = "Escurecimento Unidade")]
        public string LIMIT_ESCDOIS_UNID { get; set; }

        [Display(Name = "Resist�ncia M�nima")]
        public int? LIMIT_RES_MIN { get; set; }

        [Display(Name = "Resist�ncia M�xima")]
        public int? LIMIT_RES_MAX { get; set; }

        [Display(Name = "Resist�ncia Unidade")]
        public string LIMIT_RES_UNID { get; set; }

        [Display(Name = "Alongamento M�nimo")]
        public int? VRL_ALONG_MIN { get; set; }

        [Display(Name = "Alongamento M�ximo")]
        public int? VRL_ALONG_MAX { get; set; }

        [Display(Name = "Alongamento Unidade")]
        public string VRL_ALONG_UNID { get; set; }

        [Display(Name = "Tamanho Gr�o M�nimo")]
        public int? TAM_GRAO_MIN { get; set; }

        [Display(Name = "Tamanho Gr�o M�ximo")]
        public int? TAM_GRAO_MAX { get; set; }

        [Display(Name = "Tamanho Gr�o Unidade")]
        public string TAM_GRAO_UNID { get; set; }

        [Display(Name = "Ox�lico M�nimo")]
        public int? VLR_OXALICO_MIN { get; set; }

        [Display(Name = "Ox�lico M�ximo")]
        public int? VLR_OXALICO_MAX { get; set; }

        [Display(Name = "Ox�lico Unidade")]
        public string VLR_OXALICO_UNID { get; set; }

        [Display(Name = "Impacto M�nimo")]
        public int? VLR_IMPACTO_MIN { get; set; }

        [Display(Name = "Impacto M�ximo")]
        public int? VLR_IMPACTO_MAX { get; set; }

        [Display(Name = "Impacto Unidade")]
        public string VLR_IMPACTO_UNID { get; set; }

        [Display(Name = "Outros")]
        public string VLR_OUTROS { get; set; }

        [Display(Name = "Outro M�nimo")]
        public int? VLR_OUTRO_MIN { get; set; }

        [Display(Name = "Outro M�ximo")]
        public int? VLR_OUTRO_MAX { get; set; }

        [Display(Name = "Outro Unidade")]
        public string VLR_OUTRO_UNID { get; set; }

        [Display(Name = "Tipo Perda")]
        public string COD_TIPO_PERDA { get; set; }

        [Display(Name = "Indução")]
        [RegularExpression("^(P,E)$", ErrorMessage = "O valor não é permitido.")]
        public string VLR_INDUC { get; set; }

        [Display(Name = "Frequ�ncia")]
        public string VRL_FREQUENCIA { get; set; }

        [Display(Name = "WKG")]
        public int? VALOR_WKG { get; set; }

        [Display(Name = "Informação Fornecedor")]
        public string DESC_INFORMAC_FORN { get; set; }

        [Display(Name = "Cadastro CVTP")]
        public DateTime? DTH_CADAST_CVTP { get; set; }

        [Display(Name = "Desc. Recusa CVTP")]
        public string DESC_RECUSA_CVTP { get; set; }

        [Display(Name = "Recusa CVTP")]
        public DateTime? DTH_RECUSA_CVTP { get; set; }

        [Display(Name = "Recebimento CVTP")]
        public DateTime? DTH_RECEB_CVTP { get; set; }

        [Display(Name = "Cadastro RVTP")]
        public DateTime? DTH_CADAST_RVTP { get; set; }

        [Display(Name = "An�lise RVTP")]
        public DateTime? DTH_ANALIS_RVTP { get; set; }

        [Display(Name = "Custo Padr�o")]
        public string O { get; set; }

        [Display(Name = "Tipo Fornecedor")]
        [RegularExpression("^(S,N)$", ErrorMessage = "O valor não é permitido.")]
        public string IDC_TIPO_FORNECEDOR { get; set; }

        [Display(Name = "Produto SAP Similar")]
        public string PRODUT_SAP_SIMILAR { get; set; }

        [Display(Name = "Fluxo Rotina ID")]
        [RegularExpression("^(S,N)$", ErrorMessage = "O valor não é permitido.")]
        public string IDC_FLUXO_ROTINA { get; set; }

        [Display(Name = "Fluxo Rotina Produto")]
        public string FLUXO_ROTIN_PROD { get; set; }

        [Display(Name = "Complexo Industrial")]
        [RegularExpression("^(P,E)$", ErrorMessage = "O valor não é permitido.")]
        public string COMPLEX_INDUSTRIAL { get; set; }

        [Display(Name = "Impacto Relevante Processo")]
        [RegularExpression("^(S,N)$", ErrorMessage = "O valor não é permitido.")]
        public string IMPACT_RELEV_PROCE { get; set; }

        [Display(Name = "Impacto Relevante")]
        [RegularExpression("^(S,N)$", ErrorMessage = "O valor não é permitido.")]
        public string DESC_IMPACT_RELEV { get; set; }

        [Display(Name = "Condição Fornecedor")]
        public string DESC_CONDIC_FORNEC { get; set; }

        [Display(Name = "An�lise Risco")]
        public string DESC_ANALIS_RISCO { get; set; }

        [Display(Name = "Situação RVTP")]
        public string COD_SITUA_RVTP { get; set; }

        [Display(Name = "Envio RVTP ID")]
        public string IDC_ENVIO_RVTP { get; set; }

        [Display(Name = "Envio RVTP")]
        public DateTime? DTH_ENVIO_RVTP { get; set; }

    }
}