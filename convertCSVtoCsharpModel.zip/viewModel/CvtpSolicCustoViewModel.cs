using System;
using System.ComponentModel.DataAnnotations;

namespace Aperam.PCP.PNV.UI.ViewModels
{
    public class CVTP_SOLIC_CUSTOViewModel
    {
        [Display(Name = "Código da Solicitacao de analise de custo")]
        public int COD_SOLIC_CUSTO { get; set; }

        [Display(Name = "Código de An�lise de Controle")]
        public int? NUN_SEQ_CVTP { get; set; }

        [Display(Name = "Código do Cliente")]
        public int? COD_CLIENTE { get; set; }

        [Display(Name = "Descrição do A�o RVTP")]
        public string DESC_ACO_RVTP { get; set; }

        [Display(Name = "Descrição do Grupo CVTP")]
        public string DESC_GRUPO_CVTP { get; set; }

        [Display(Name = "Código do Acabamento/Revestimento")]
        public string COD_ACAB_REVEST { get; set; }

        [Display(Name = "Detalhamento das Dimens�es para An�lise")]
        public string DETAL_DIMENS_ANALIS { get; set; }

        [Display(Name = "Custo Direto ABC")]
        public int? CUSTO_DIRETO_ABC { get; set; }

        [Display(Name = "Data e Hora de Cadastro do Registro")]
        public DateTime? DTH_CAD_REG { get; set; }

        [Display(Name = "Código de Registro de Usu�rio")]
        public int? COD_REG_USUAR { get; set; }

        [Display(Name = "Código de Registro de Empregado")]
        public int? COD_REG_EMPRG { get; set; }

        [Display(Name = "N�mero Sequencial CVTP")]
        public int? COD_SEG_CVTP { get; set; }

    }
}