using System;
using System.ComponentModel.DataAnnotations;

namespace Aperam.PCP.PNV.UI.ViewModels
{
    public class CVTP_PROPR_MECANICAViewModel
    {
        [Display(Name = "N�mero da Proposta Mec�nica")]
        public int NUN_PROPR_MECAN { get; set; }

        [Display(Name = "N�mero Sequencial CVTP")]
        public int? NUN_SEQ_CVTP { get; set; }

        [Display(Name = "Código do Conjunto da Proposta")]
        public int? COD_CONJ_PROP { get; set; }

        [Display(Name = "Especificação Nominal do Produto")]
        public int? ESP_NOM_PRODT { get; set; }

        [Display(Name = "Toler�ncia M�nima da Especificação")]
        public int? TOL_MIN_ESP { get; set; }

        [Display(Name = "Toler�ncia M�xima da Especificação")]
        public int? TOL_MAX_ESP { get; set; }

        [Display(Name = "Largura Nominal do Produto")]
        public int? LAR_NOM_PRODT { get; set; }

        [Display(Name = "Toler�ncia M�nima da Largura")]
        public int? TOL_MIN_LAR { get; set; }

        [Display(Name = "Toler�ncia M�xima da Largura")]
        public int? TOL_MAX_LAR { get; set; }

        [Display(Name = "Comprimento Nominal do Produto")]
        public int? COMP_NOM_PRODT { get; set; }

        [Display(Name = "Toler�ncia M�nima do Comprimento")]
        public int? TOL_MIN_COMP { get; set; }

        [Display(Name = "Toler�ncia M�xima do Comprimento")]
        public int? TOL_MAX_COMP { get; set; }

        [Display(Name = "Código do Tipo de Borda")]
        [RegularExpression("^(BA, BN)$", ErrorMessage = "O valor não é permitido.")]
        public string COD_TIPO_BORDA { get; set; }

        [Display(Name = "Data e Hora de Cadastro do Registro")]
        public DateTime? DTH_CAD_REG { get; set; }

        [Display(Name = "Código de Registro de Usu�rio")]
        public int? COD_REG_USUAR { get; set; }

        [Display(Name = "Código de Registro de Empregado")]
        public int? COD_REG_EMPRG { get; set; }

    }
}