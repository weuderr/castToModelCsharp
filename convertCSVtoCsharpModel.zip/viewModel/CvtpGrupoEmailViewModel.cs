using System;
using System.ComponentModel.DataAnnotations;

namespace Aperam.PCP.PNV.UI.ViewModels
{
    public class CVTP_GRUPO_EMAILViewModel
    {
        [Display(Name = "Código do Grupo de �rea")]
        public int COD_GRUPO_AREA { get; set; }

        [Display(Name = "N�mero Sequencial CVTP")]
        public int? NUN_SEQ_CVTP { get; set; }

        [Display(Name = "Descrição do Grupo de �rea")]
        public string DESC_GRUPO_AREA { get; set; }

        [Display(Name = "�rea do Grupo Direcionado")]
        public string AREA_GRUPO_DIREC { get; set; }

        [Display(Name = "Sub�rea do Grupo Direcionado")]
        public string SUBAREA_GRUPO_DIREC { get; set; }

        [Display(Name = "Data e Hora de Cadastro do Registro")]
        public DateTime? DTH_CAD_REG { get; set; }

        [Display(Name = "Código de Registro de Usu�rio")]
        public int? COD_REG_USUAR { get; set; }

        [Display(Name = "Código de Registro de Empregado")]
        public int? COD_REG_EMPRG { get; set; }

    }
}