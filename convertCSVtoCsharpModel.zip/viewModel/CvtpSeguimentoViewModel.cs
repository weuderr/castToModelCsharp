using System;
using System.ComponentModel.DataAnnotations;

namespace Aperam.PCP.PNV.UI.ViewModels
{
    public class CVTP_SEGUIMENTOViewModel
    {
        [Display(Name = "Código de Segmento CVTP")]
        public int COD_SEG_CVTP { get; set; }

        [Display(Name = "Descrição do Segmento")]
        public string DESC_SEGUIMENTO { get; set; }

        [Display(Name = "Data e Hora de Cadastro do Registro")]
        public DateTime? DTH_CAD_REG { get; set; }

        [Display(Name = "Código de Registro de Usu�rio")]
        public int? COD_REG_USUAR { get; set; }

        [Display(Name = "Código de Registro de Empregado")]
        public int? COD_REG_EMPRG { get; set; }

    }
}