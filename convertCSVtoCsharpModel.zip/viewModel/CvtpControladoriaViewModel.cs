using System;
using System.ComponentModel.DataAnnotations;

namespace Aperam.PCP.PNV.UI.ViewModels
{
    public class CVTP_CONTROLADORIAViewModel
    {
        [Display(Name = "Código de An�lise de Controle")]
        public int COD_ANALIS_CONTROL { get; set; }

        [Display(Name = "N�mero Sequencial CVTP")]
        public int? NUN_SEQ_CVTP { get; set; }

        [Display(Name = "Código de Revis�o CVTP")]
        public int? COD_REVIS_CVTP { get; set; }

        [Display(Name = "Código de Registro de Usu�rio")]
        public int? COD_REG_USUAR { get; set; }

        [Display(Name = "Código de Registro de Empregado")]
        public int? COD_REG_EMPRG { get; set; }

        [Display(Name = "Código da Sigla da Lotação")]
        public string COD_SIGLA_LOTAC { get; set; }

        [Display(Name = "E-mail de An�lise de Custo")]
        public string EMAIL_ANALIS_CUSTO { get; set; }

        [Display(Name = "Produto SAP Similar")]
        public string PRODUT_SAP_SIMILAR { get; set; }

        [Display(Name = "Ano e M�s de Refer�ncia")]
        public DateTime? ANO_MES_REFER { get; set; }

        [Display(Name = "Quantidade de A�o para An�lise de Custo")]
        public int? O_ANALCUSTO { get; set; }

        [Display(Name = "Status da An�lise de Custo")]
        public string STATUS_ANALIS_CUSTO { get; set; }

        [Display(Name = "Data e Hora de In�cio da An�lise de Custo")]
        public DateTime? DTH_INIC_ANALCUSTO { get; set; }

        [Display(Name = "Data e Hora de Envio da An�lise de Custo")]
        public DateTime? DTH_ENVIO_ANALCUSTO { get; set; }

    }
}