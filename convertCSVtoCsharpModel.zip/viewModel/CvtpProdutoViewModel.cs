using System;
using System.ComponentModel.DataAnnotations;

namespace Aperam.PCP.PNV.UI.ViewModels
{
    public class CVTP_PRODUTOViewModel
    {
        [Display(Name = "Sequ�ncia")]
        public int NUN_SEQ_CVTP { get; set; }

        [Display(Name = "Seguimento")]
        public int? COD_SEG_CVTP { get; set; }

        [Display(Name = "Cliente")]
        public int? COD_CLIENTE { get; set; }

        [Display(Name = "Linha de Produto")]
        public string COD_LINHA_PRODT { get; set; }

        [Display(Name = "Revis�o")]
        public int? COD_REVIS_CVTP { get; set; }

        [Display(Name = "�rea de Aplicação")]
        public string COD_AREA_APLIC { get; set; }

        [Display(Name = "Situação")]
        public string COD_SITUA_CVTP { get; set; }

        [Display(Name = "Descrição Complexa")]
        public string DESC_COMPLEX_CVTP { get; set; }

        [Display(Name = "Usu�rio Registrado")]
        public int? COD_REG_USUAR { get; set; }

        [Display(Name = "Empregado Registrado")]
        public int? COD_REG_EMPRG { get; set; }

        [Display(Name = "Mercado")]
        [RegularExpression("^(MI, ME)$", ErrorMessage = "O valor não é permitido.")]
        public string COD_MERC_CVTP { get; set; }

        [Display(Name = "Descrição de Outro Segmento")]
        public string DESC_OUTRO_SEG { get; set; }

        [Display(Name = "Motivo da Consulta")]
        public string DESC_MOTIV_CONSULTA { get; set; }

        [Display(Name = "Custo de Envio")]
        public string COD_ENVIO_CUSTO { get; set; }

        [Display(Name = "Setor Automotivo")]
        public string COD_SETOR_AUTOMOT { get; set; }

        [Display(Name = "A�o Interno")]
        public string ACO_INTERN_CVTP { get; set; }

        [Display(Name = "Identificação FM A�o")]
        public string COD_IDENT_FMACO { get; set; }

        [Display(Name = "Identificação A�o Externo")]
        public string COD_IDENT_ACOEX { get; set; }

        [Display(Name = "Acabamento e Revestimento")]
        public string COD_ACAB_REVEST { get; set; }

        [Display(Name = "Descrição do Grupo")]
        public string DESC_GRUPO_CVTP { get; set; }

        [Display(Name = "Descrição da Aplicação")]
        public string DESC_APLIC_CVTP { get; set; }

        [Display(Name = "Quantidade Fornecida")]
        public int? DESC_QTD_FORNEC { get; set; }

        [Display(Name = "Norma de Refer�ncia")]
        public string NORMA_REFER_CVTP { get; set; }

        [Display(Name = "Norma do Cliente")]
        [RegularExpression("^(s,n)$", ErrorMessage = "O valor não é permitido.")]
        public string COD_NORM_CLIENTE { get; set; }

        [Display(Name = "Descrição da Norma do Cliente")]
        public string DESC_NORMA_CLIENTE { get; set; }

        [Display(Name = "Composição Qu�mica")]
        [RegularExpression("^(P, E)$", ErrorMessage = "O valor não é permitido.")]
        public string DESC_COMP_QUIMICA { get; set; }

        [Display(Name = "Dimens�o do Produto")]
        [RegularExpression("^(P, E)$", ErrorMessage = "O valor não é permitido.")]
        public string COD_DIMENS_PROD { get; set; }

        [Display(Name = "Toler�ncia do Produto")]
        [RegularExpression("^(A, P, E)$", ErrorMessage = "O valor não é permitido.")]
        public string DESC_TOLER_PROD { get; set; }

        [Display(Name = "Padronização Espec�fica")]
        [RegularExpression("^(C, N, P)$", ErrorMessage = "O valor não é permitido.")]
        public string DESC_PADRONIZ_ESP { get; set; }

        [Display(Name = "Quantidade de Conjunto de Dimens�es")]
        public int? QTD_CONJ_DIMENS { get; set; }

        [Display(Name = "Peso L�quido do Produto")]
        [RegularExpression("^(P, E)$", ErrorMessage = "O valor não é permitido.")]
        public int? PES_LIQUI_PROD { get; set; }

        [Display(Name = "Posição da Bobina/Tira")]
        [RegularExpression("^(H, V)$", ErrorMessage = "O valor não é permitido.")]
        public string POS_BOB_TIRA { get; set; }

        [Display(Name = "Di�metro Interno da Bobina")]
        [RegularExpression("^(P,E)$", ErrorMessage = "O valor não é permitido.")]
        public string DIAM_INTERN_BOB { get; set; }

        [Display(Name = "Valor do Di�metro Espec�fico")]
        public int? VLR_DIAM_ESPEC { get; set; }

        [Display(Name = "Ensaio de Laborat�rio")]
        [RegularExpression("^(P,E)$", ErrorMessage = "O valor não é permitido.")]
        public string COD_ENSAIO_LABOR { get; set; }

        [Display(Name = "Valor de Dureza M�nima")]
        public int? VLR_DUREZA_MIN { get; set; }

        [Display(Name = "Valor de Dureza M�xima")]
        public int? VLR_DUREZA_MAX { get; set; }

        [Display(Name = "Unidade de Dureza")]
        public string VLR_UNID_DUREZA { get; set; }

        [Display(Name = "Limite Escuma M�nimo")]
        public int? LIMIT_ESCUM_MIN { get; set; }

        [Display(Name = "Limite Escuma M�ximo")]
        public int? LIMIT_ESCUM_MAX { get; set; }

        [Display(Name = "Unidade de Limite de Escuma")]
        public string LIMIT_ESCUM_UNID { get; set; }

        [Display(Name = "Limite ESC2 M�nimo")]
        public int? LIMIT_ESCDOIS_MIN { get; set; }

        [Display(Name = "Limite ESC2 M�ximo")]
        public int? LIMIT_ESCDOIS_MAX { get; set; }

        [Display(Name = "Unidade de Limite ESC2")]
        public string LIMIT_ESCDOIS_UNID { get; set; }

        [Display(Name = "Limite Residual M�nimo")]
        public int? LIMIT_RES_MIN { get; set; }

        [Display(Name = "Limite Residual M�ximo")]
        public int? LIMIT_RES_MAX { get; set; }

        [Display(Name = "Unidade de Limite Residual")]
        public string LIMIT_RES_UNID { get; set; }

        [Display(Name = "Valor Alongamento M�nimo")]
        public int? VRL_ALONG_MIN { get; set; }

        [Display(Name = "Valor Alongamento M�ximo")]
        public int? VRL_ALONG_MAX { get; set; }

        [Display(Name = "Unidade de Valor de Alongamento")]
        public string VRL_ALONG_UNID { get; set; }

        [Display(Name = "Tamanho de Gr�o M�nimo")]
        public int? TAM_GRAO_MIN { get; set; }

        [Display(Name = "Tamanho de Gr�o M�ximo")]
        public int? TAM_GRAO_MAX { get; set; }

        [Display(Name = "Unidade de Tamanho de Gr�o")]
        public string TAM_GRAO_UNID { get; set; }

        [Display(Name = "Valor Ox�lico M�nimo")]
        public int? VLR_OXALICO_MIN { get; set; }

        [Display(Name = "Valor Ox�lico M�ximo")]
        public int? VLR_OXALICO_MAX { get; set; }

        [Display(Name = "Unidade de Valor Ox�lico")]
        public string VLR_OXALICO_UNID { get; set; }

        [Display(Name = "Valor de Impacto M�nimo")]
        public int? VLR_IMPACTO_MIN { get; set; }

        [Display(Name = "Valor de Impacto M�ximo")]
        public int? VLR_IMPACTO_MAX { get; set; }

        [Display(Name = "Unidade de Valor de Impacto")]
        public string VLR_IMPACTO_UNID { get; set; }

        [Display(Name = "Valor Outros")]
        public string VLR_OUTROS { get; set; }

        [Display(Name = "Valor Outro M�nimo")]
        public int? VLR_OUTRO_MIN { get; set; }

        [Display(Name = "Valor Outro M�ximo")]
        public int? VLR_OUTRO_MAX { get; set; }

        [Display(Name = "Unidade de Valor Outro")]
        public string VLR_OUTRO_UNID { get; set; }

        [Display(Name = "Tipo de Perda")]
        [RegularExpression("^(P,E)$", ErrorMessage = "O valor não é permitido.")]
        public string COD_TIPO_PERDA { get; set; }

        [Display(Name = "Valor Indução")]
        public string VLR_INDUC { get; set; }

        [Display(Name = "Frequ�ncia")]
        public string VRL_FREQUENCIA { get; set; }

        [Display(Name = "Valor WKG")]
        public int? VALOR_WKG { get; set; }

        [Display(Name = "Descrição Informação Fornecida")]
        public string DESC_INFORMAC_FORN { get; set; }

        [Display(Name = "Data de Cadastro")]
        public DateTime? DTH_CADAST_CVTP { get; set; }

        [Display(Name = "Descrição de Recusa")]
        public string DESC_RECUSA_CVTP { get; set; }

        [Display(Name = "Data de Recusa")]
        public DateTime? DTH_RECUSA_CVTP { get; set; }

        [Display(Name = "Data de Recebimento")]
        public DateTime? DTH_RECEB_CVTP { get; set; }

        [Display(Name = "Data de Cadastro RVTP")]
        public DateTime? DTH_CADAST_RVTP { get; set; }

        [Display(Name = "Data de An�lise RVTP")]
        public DateTime? DTH_ANALIS_RVTP { get; set; }

        public byte[]? COD_ARQUI_ANEXO { get; set; }

    }
}