using System;
using System.ComponentModel.DataAnnotations;

namespace Aperam.PCP.PNV.UI.ViewModels
{
    public class CVTP_ANALIS_QUIMICAViewModel
    {
        [Display(Name = "Código do Elemento Qu�mico")]
        public int COD_ELEM_QUIMICO { get; set; }

        [Display(Name = "N�mero Sequencial CVTP")]
        public int? NUN_SEQ_CVTP { get; set; }

        [Display(Name = "Código da Unidade do Elemento")]
        public string COD_UNID_ELEM { get; set; }

        [Display(Name = "N�mero do Valor M�nimo")]
        public int? NUM_VLR_MIN { get; set; }

        [Display(Name = "N�mero do Valor M�ximo")]
        public int? NUM_VLR_MAX { get; set; }

        [Display(Name = "Data e Hora de Cadastro do Registro")]
        public DateTime? DTH_CAD_REG { get; set; }

        [Display(Name = "Código de Registro de Usu�rio")]
        public int? COD_REG_USUAR { get; set; }

        [Display(Name = "Código de Registro de Empregado")]
        public int? COD_REG_EMPRG { get; set; }

    }
}