using System;
using System.ComponentModel.DataAnnotations;

namespace Aperam.PCP.PNV.UI.ViewModels
{
    public class CVTP_SOLIC_ANALISEViewModel
    {
        [Display(Name = "Código da Solicitação de An�lise")]
        public int COD_SOLIC_ANALISE { get; set; }

        [Display(Name = "N�mero Sequencial CVTP")]
        public int? NUN_SEQ_CVTP { get; set; }

        [Display(Name = "Procedimento de Solicitação de An�lise")]
        [RegularExpression("^(ESP, CO)$", ErrorMessage = "O valor não é permitido.")]
        public string PROC_SOLIC_ANALIS { get; set; }

        [Display(Name = "Data e Hora da Solicitação de An�lise")]
        public DateTime? DHT_SOLIC_ANALISE { get; set; }

        [Display(Name = "Email de Envio de An�lise")]
        public string EMAIL_ENVIO_ANALISE { get; set; }

        [Display(Name = "Código da �rea de Solicitação")]
        public string COD_AREA_SOLICIT { get; set; }

        [Display(Name = "Email Direcionado de Email")]
        public string EMAIL_DIREC_EMAIL { get; set; }

        [Display(Name = "Descrição Detalhada de Email")]
        public string DESC_DETAL_EMAIL { get; set; }

        [Display(Name = "Data e Hora Limite de Retorno")]
        public DateTime? DTH_LIMITE_RETORN { get; set; }

        [Display(Name = "Usu�rio da Solicitação de An�lise")]
        public int? USUAR_SOLIC_ANALIS { get; set; }

        [Display(Name = "Empregado da Solicitação de An�lise")]
        public int? EMPRG_SOLIC_ANALIS { get; set; }

        [Display(Name = "Descrição de An�lise de Email")]
        public string DESC_ANALIS_EMAIL { get; set; }

        [Display(Name = "Data e Hora de Retorno de An�lise")]
        public DateTime? DHT_RETORN_ANALISE { get; set; }

        [Display(Name = "Indicador de Anexo de An�lise")]
        public string IDC_ANEXO_ANALISE { get; set; }

        [Display(Name = "Usu�rio de Retorno de An�lise")]
        public int? USUAR_RETOR_ANALIS { get; set; }

        [Display(Name = "Empregado de Retorno de An�lise")]
        public int? EMPRG_RETOR_ANALIS { get; set; }

    }
}